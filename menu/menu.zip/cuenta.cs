﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace menu
{
    internal class cuenta
    {
        public int id;
        public double cuentaTotal;
        public double pagoDolares;
        public double porcentajePropina;
        public double totalPesos;
        public double totalDolares;
    }
}
